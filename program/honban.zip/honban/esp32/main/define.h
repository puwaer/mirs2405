#define PIN_MR8_A   39
#define PIN_MR8_B   34
#define PIN_MR8_C   35
#define PIN_MR8_D   32
#define PIN_MR8_E   33
#define PIN_MR8_F   25
#define PIN_MR8_G   26
#define PIN_MR8_H   27

/*
#define PIN_MR8_A   3
#define PIN_MR8_B   5
#define PIN_MR8_C   6
#define PIN_MR8_D   9
#define PIN_MR8_E   10
#define PIN_MR8_F   11
*/
