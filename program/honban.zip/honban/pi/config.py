# シリアルポート設定
ESP_PORT = '/dev/ttyUSB0'
PICO_PORT = '/dev/ttyACM0'
ARDUINO_PORT = '/dev/ttyACM0'
#JETSON_PORT = '/dev/'

# ボーレート
BAUDRATE = 115200
