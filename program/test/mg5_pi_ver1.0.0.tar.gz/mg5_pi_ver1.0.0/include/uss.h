#ifndef __USS__
#define __USS__

extern int  uss_open_l();
extern int  uss_open_r();
extern long uss_get_l();
extern long uss_get_r();

#endif
