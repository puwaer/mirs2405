#ifndef __IO__
#define __IO__

extern int  io_open();
extern void io_get_sw(int *sw_f, int *sw_l, int *sw_r);

#endif
