#ifndef __SERVER__
#define __SERVER__

extern int server_info_number(int num);

#endif
