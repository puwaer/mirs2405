#ifndef __GET_IMG__
#define __GET_IMG__

extern int get_img(const char *filename, int device, int widht, int height);

#endif
